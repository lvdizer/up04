namespace AuthorizationPractice
{
    public static class Database
    {
        public static string ConnectionString =
            @"Server=.\SQLEXPRESS;Database=AuthorizationPractice;Trusted_Connection=True;";
    }
}
