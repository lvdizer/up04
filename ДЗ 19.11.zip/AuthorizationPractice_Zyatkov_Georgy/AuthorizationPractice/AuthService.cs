using System;
using System.Data;
using System.Data.SqlClient;

namespace AuthorizationPractice
{
    public class AuthService
    {
        public User Login(string login, string password)
        {
            const string sql = @"
SELECT u.Id, u.Login, u.FullName, u.RoleId, r.Name AS RoleName,
       u.IsActive, u.PasswordHash
FROM Users AS u
INNER JOIN Roles AS r ON r.Id = u.RoleId
WHERE u.Login = @Login;";

            using (var connection = new SqlConnection(Database.ConnectionString))
            using (var command = new SqlCommand(sql, connection))
            {
                command.Parameters.Add("@Login", SqlDbType.NVarChar, 100).Value = login;
                connection.Open();

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    if (!reader.Read())
                        return null;

                    bool isActive = Convert.ToBoolean(reader["IsActive"]);
                    if (!isActive)
                        return null;

                    string passwordHash = Convert.ToString(reader["PasswordHash"]);
                    if (!PasswordHasher.Verify(password, passwordHash))
                        return null;

                    return new User
                    {
                        Id = Convert.ToInt32(reader["Id"]),
                        Login = Convert.ToString(reader["Login"]),
                        FullName = Convert.ToString(reader["FullName"]),
                        RoleId = Convert.ToInt32(reader["RoleId"]),
                        RoleName = Convert.ToString(reader["RoleName"]),
                        IsActive = isActive
                    };
                }
            }
        }
    }
}
