using System.Windows;

namespace AuthorizationPractice
{
    public partial class MainWindow : Window
    {
        public MainWindow(User user)
        {
            InitializeComponent();
            FullNameText.Text = "ФИО: " + user.FullName;
            LoginText.Text = "Логин: " + user.Login;
            RoleText.Text = "Роль: " + user.RoleName;
        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            var loginWindow = new LoginWindow();
            loginWindow.Show();
            Close();
        }
    }
}
