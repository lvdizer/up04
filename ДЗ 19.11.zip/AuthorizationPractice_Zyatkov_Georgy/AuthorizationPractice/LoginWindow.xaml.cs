using System;
using System.Data.SqlClient;
using System.Windows;

namespace AuthorizationPractice
{
    public partial class LoginWindow : Window
    {
        private readonly AuthService _authService = new AuthService();

        public LoginWindow()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string login = LoginTextBox.Text.Trim();
            string password = PasswordInput.Password;

            if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(password))
            {
                ErrorTextBlock.Text = "Заполните логин и пароль.";
                return;
            }

            try
            {
                User user = _authService.Login(login, password);
                if (user == null)
                {
                    ErrorTextBlock.Text = "Неверный логин или пароль, либо учётная запись отключена.";
                    return;
                }

                var mainWindow = new MainWindow(user);
                mainWindow.Show();
                Close();
            }
            catch (SqlException)
            {
                ErrorTextBlock.Text = "Не удалось подключиться к базе данных. Проверьте, запущен ли SQL Server.";
            }
            catch (Exception)
            {
                ErrorTextBlock.Text = "Произошла ошибка при авторизации.";
            }
        }
    }
}
