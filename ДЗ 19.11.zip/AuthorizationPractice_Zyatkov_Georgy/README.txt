Домашняя работа: модуль авторизации ADO.NET
Студент: Зятьков Георгий
Проект: WPF App (.NET Framework 4.7), C# 7.3

В комплект входят:
- AuthorizationPractice.sln — решение Visual Studio;
- AuthorizationPractice/ — исходный код WPF-приложения;
- AuthorizationPractice.sql — SQL-скрипт преподавателя для создания базы и тестовых записей.

Порядок запуска:
1. Откройте AuthorizationPractice.sql в SQL Server Management Studio.
2. Подключитесь к .\SQLEXPRESS через Windows Authentication.
3. Выполните скрипт клавишей F5. Он создаст базу AuthorizationPractice,
   таблицы Roles и Users и три тестовые учётные записи.
4. Откройте AuthorizationPractice.sln в Visual Studio.
5. Убедитесь, что целевая платформа — .NET Framework 4.7 и есть ссылка System.Data.
6. Соберите и запустите проект.

Строка подключения находится в Database.cs:
Server=.\SQLEXPRESS;Database=AuthorizationPractice;Trusted_Connection=True;

Проверка пароля:
PasswordHasher.cs использует PBKDF2 через Rfc2898DeriveBytes.
Формат PasswordHash точно соответствует SQL-файлу преподавателя:
iterations.saltBase64.hashBase64
Например, 100000.salt.hash. Введённый пароль не сохраняется в объекте User.

Тестовые учётные записи:
admin / Admin123!
support1 / Support123!
user1 / User123!

Примечание:
Скриншоты фактического запуска и загрузку в GitHub нужно выполнить после запуска
на компьютере с SQL Server и входа в свой GitHub-аккаунт.
